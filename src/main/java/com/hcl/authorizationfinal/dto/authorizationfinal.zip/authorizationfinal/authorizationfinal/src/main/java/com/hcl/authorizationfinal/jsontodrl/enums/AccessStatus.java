package com.hcl.authorizationfinal.jsontodrl.enums;

public enum AccessStatus {
    ALLOWED,
    DENIED
}