package com.hcl.authorizationfinal.dto.rule;
import com.hcl.authorizationfinal.dto.rule.ConditionalJson;

import java.util.List;

public class CreateBusinessRuleInputJson {
    private ConditionalJson conditionalJson;

    // Getters and Setters

    public ConditionalJson getConditionalJson() {
        return conditionalJson;
    }

    public void setConditionalJson(ConditionalJson conditionalJson) {
        this.conditionalJson = conditionalJson;
    }




    }
