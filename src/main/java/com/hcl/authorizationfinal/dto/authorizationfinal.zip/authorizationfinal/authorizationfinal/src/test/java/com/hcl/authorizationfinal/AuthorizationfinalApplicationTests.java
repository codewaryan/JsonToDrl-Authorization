package com.hcl.authorizationfinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorizationfinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
