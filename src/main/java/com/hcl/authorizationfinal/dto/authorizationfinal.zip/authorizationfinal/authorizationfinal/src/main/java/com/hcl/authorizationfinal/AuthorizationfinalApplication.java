package com.hcl.authorizationfinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthorizationfinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthorizationfinalApplication.class, args);
	}

}
